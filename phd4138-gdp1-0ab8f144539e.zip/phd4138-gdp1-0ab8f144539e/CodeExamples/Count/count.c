#include<stdio.h>

int main() {
  int i; 
  printf("Los geht's\n");
  for (i = 0;
      i<5; 
      i++) {
    printf("Wert von i:%d\n",i);
  }
  printf("Fertig\n");
  return 0;
}
