In dieser Demo wird erklärt, wieso man in speziellen
Situationen die Anweisung

  fflush(stdout)

nach einer printf-Anweisung ausführen muss.

