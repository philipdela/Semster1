Dieses Beispiel zeigt, wie man die Hilfsfunktion readInteger()
entwickeln kann, die das Einlesen einer ganzen Zahl elegant erledigt.


