Dieses Beispiel zeigt, wie aus Pseudo-Code ein
ablauffähiges C-Programm wird.
