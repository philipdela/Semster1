{
    Lies zwei Ganzahlen >= 0 ein und weise sie x und y zu ;

    while (x > 0) {
        if (x < y) {
            Vertausche x und y;
        }
        x = x - y;
    }

    Ausgabe von y;
}
