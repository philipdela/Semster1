/* Berechne Rest r bei ganzzahliger Division a/b */
{
    Eingabe ganzer Zahlen a und b mit a>= 0, b > 0 ;

    while ( a >= b ) {
        a = a - b;
    }
    /* Der Rest r der Division ist der Wert der Variable a */
    Ausgabe a; 
}
