Just use the simple CodeRunner plugin.
No configuration files in .vscode are needed.
