{
    {
        // Urlaub planen;
        Reisepartner festlegen;
        Urlaubsziel festlegen;
        Budget festlegen;
    }

    { 
        // Urlaub antreten;
        Koffer packen;
        Reise antreten;
        Am Urlaubsort wohlfuehlen;
        Rueckreise antreten;
        Koffer auspacken;
    }
}
